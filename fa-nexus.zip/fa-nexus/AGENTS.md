# FA Nexus Agent Notes

## Environment Paths
- Windows install root: `D:\Software\Foundry_VTT\Foundry Virtual Tabletop`
- WSL translation: `/mnt/d/Software/Foundry_VTT/Foundry Virtual Tabletop` (use `wslpath 'D:\Software\Foundry_VTT\Foundry Virtual Tabletop'` if you forget)
- Foundry data directory: `C:\Users\PC\AppData\Local\FoundryVTT\Data` → `/mnt/c/Users/PC/AppData/Local/FoundryVTT/Data`
- Foundry V13 api documentation: `https://foundryvtt.com/api/v13/`
- Module location in data directory: `modules/fa-nexus`

## Gotchas & Practices

### ApplicationV2 helper pattern
Always use ApplicationV2 for new windows and Dialogs.
When subclassing Foundry VTT ApplicationV2, always pull both constructors: `const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;` and export classes as `HandlebarsApplicationMixin(ApplicationV2)`. Mixing in later or forgetting the mixin breaks templates and event lifecycle.

### Canvas lifecycle is mandatory
Both `PathManager` and `TexturePaintManager` throw immediately if `canvas`, `canvas.ready`, or `canvas.stage` are unavailable (`scripts/paths/path-manager.js` delegates to the premium bundle, `scripts/textures/texture-paint-manager.js` likewise). Only initialize these tools after `Hooks.once('canvasReady', ...)` fires, and provide stubs for `canvas`, `ui`, and `Hooks` when running outside Foundry (tests, storybook, etc.).

### Remember to unwind interactivity locks
`PathManager` and `TexturePaintManager` register their listeners through the shared `CanvasInteractionController`, which acquires and releases tile interactivity for you (`scripts/paths/path-manager.js`, `scripts/textures/texture-paint-manager.js`). Always wrap usage in `try/finally` and call `stop()` on abort so the controller session can restore interactivity and detach listeners.

### 200px-per-grid assumptions
Both placement managers assume FA assets are authored at 200px per grid square when computing widths, repeats, and brush scales (see `premium_features/path-editor-[module_version].js` and `premium_features/texture-editor-[module_version].js` for the authoritative constants). If new content uses a different base resolution, update these constants in the premium bundles **and** the shared helpers (`scripts/paths/path-geometry.js`, `scripts/textures/texture-render.js`) together.

### Sort & elevation heuristics are fragile
New preview layers estimate their `sort` z-order by scanning existing tiles at the same elevation (`scripts/paths/path-manager.js:900-916`, `scripts/textures/texture-paint-manager.js:143-172`). Extremely stacked scenes can still render out-of-order; expose manual overrides if artists complain.

### Shared asset catalog cache
`AssetsTab.loadAssets` relies on the module-level `SHARED_ASSET_CATALOG` cache (`scripts/assets/assets-tab.js:11,354-388`). Whenever code mutates the asset list (reindex, folder settings, cloud refresh) mark it dirty so other tabs refresh: `SHARED_ASSET_CATALOG.dirty = true`.

### Cloud sync requires live network
`NexusContentService.sync` fetches manifests from `https://n8n.forgotten-adventures.net/...` and bails if offline (`scripts/services/nexus-content-service.js:65-143`). Offline mode is still TODO, so gate UI affordances and surface friendly errors instead of retry loops.

### Premium URLs need OAuth state
`getFullURL` throws `'AUTH'` when `patreon_auth_data.state` is missing (`scripts/services/nexus-content-service.js:171-198`). Catch this and prompt users to authenticate before retrying downloads; do not treat it as a generic network failure.

### FilePicker-only download paths
`NexusDownloadManager` builds directories and scans files through `foundry.applications.apps.FilePicker.implementation` (`scripts/services/nexus-download-manager.js:32-137`). Outside the client (WSL scripts, tests), that implementation is undefined—guard access or stub it before calling `initialize()`.

### Local inventory depends on settings JSON
`collectLocalInventory` reads enabled folders from a JSON string in `game.settings` (`scripts/services/nexus-content-service.js:239-318`). When adjusting folder settings, always write stringified arrays and call `SHARED_ASSET_CATALOG.dirty = true` so caches update.

### Tab locking & search persistence
The assets tab locks navigation during long operations and restores it via `_setIndexingLock(false)` (`scripts/assets/assets-tab.js:63-112`); ensure every new async path clears the lock on completion or cancellation. Search queries are stored per-tab via the `_tabSearch` map and `game.settings` (`scripts/nexus-app.js:66-140`), so new tabs must register keys to avoid leaking state between views.

### Tile rendering override pattern
When custom renderers replace a tile's visuals (scatter, masked tiling, chunked flatten, etc.), keep `doc.texture.src` pointing at a real image but force the mesh to a shared transparent placeholder at runtime. Use a per-feature original texture slot (e.g., `faNexusAssetScatterOriginalTexture`, `faNexusFlattenOriginalTexture`) so overlays don't fight over `faNexusOriginalTexture`. Always `await ensureTileMesh(tile)` before swapping, attach your container to the mesh, and reapply on `drawTile`, `refreshTile`, `hoverTile`, and `controlTile`. Cleanup must restore the original texture and destroy the container. Prefer `getTransparentTexture()` over writing new placeholder files in `/worlds/*/assets/tiles`.

### GPU texture caps
`TexturePaintManager` clamps render textures to the detected `MAX_TEXTURE_SIZE` with a safe 8192 ceiling (`scripts/textures/texture-paint-manager.js:136-213,481-501`). If you see missing masks on low-end GPUs, reduce scene extents or add chunked painting instead of raising the cap.

### Premium bundles workflow (Oct 2025)
- Interactive editors live in remote ES modules delivered via Cloudflare R2. Public managers at `scripts/paths/path-manager.js` and `scripts/textures/texture-paint-manager.js` are thin proxies that dynamically load premium bundles via `premiumFeatureBroker.require()`.
- Source-of-truth editing code: `premium_features/path-editor-[module_version].js` (paths) and `premium_features/texture-editor-[module_version].js` (texture masking). After modifying these files you **must** rebuild the bundle, upload to R2, and update the n8n entitlement workflow with the new SHA-256 hash. The repo copy does not auto-deploy.
- Do **not** edit existing versioned bundle files in-place. Copy the latest version to a new filename with a bumped `[module_version]` (e.g. `texture-editor-0.0.3.js`), make changes there, and regenerate hashes/manifest entries for the new bundle version.
- Legacy `premium_features/path-manager-premium.js` and `premium_features/texture-paint-manager-premium.js` are archived for reference only. Runtime code uses the new bundle system exclusively.
- Entitlements are managed by `PremiumEntitlementsService` and `PremiumFeatureBroker`. Features are registered via `premium-feature-registry.js` with entitlement keys and bundle mappings.
- No signing keys used; SHA-256 hash verification ensures bundle integrity. n8n production workflow is live and handles authentication validation.

### R2 upload checklist
1. Run bundle build (TODO: wire `pnpm build premium`). Output: `path-editor.[hash].js` & `texture-editor.[hash].js` ES modules.
2. Upload artifacts to Cloudflare R2 bucket `fa-nexus-premium` under `path-editor/` and `texture-editor/` directories.
3. Calculate SHA-256 hashes: `sha256sum premium_features/path-editor-*.js premium_features/texture-editor-*.js`
4. Update `premium-bundle-manifest.md` with new hashes and n8n workflow manifest object.
5. Update n8n `foundry-nexus-premium-entitlements` endpoint with new bundle URLs and hashes.
6. Test: authenticated users load bundles without errors; unauthenticated users see lock messaging; existing tiles render normally.
7. Ensure `module.json` version matches the newest premium bundle version before packaging.

## Quick sanity checklist
- Canvas ready? (`canvas.ready === true`)
- Tabs unlocked before returning control? (`app.setTabsLocked(false)`)
- Shared catalog invalidated after local/cloud changes?
- Auth prompts shown when `getFullURL` throws `AUTH`?
- Windows ↔︎ WSL paths double-checked before launching Foundry?
